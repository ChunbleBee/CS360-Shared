#! /bin/bash
sudo mount -o loop diskimage /mnt/360disk
ls -al /mnt
sudo umount /mnt/360disk

